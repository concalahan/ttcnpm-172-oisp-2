var express = require("express");
var mysql = require('mysql2');
var router = express.Router();

router.get('/hihi', function(req, res) {
  require( 'wpapi' ).site( 'http://aztechpro.com/wp-json/' ).auth({
    username: 'admin',
    password: 'Haiconcacon123'
  }).users().me().then(function( user ) {
    console.log( user );
  });
});

router.get('/db', function(req, res) {
  var connection = mysql.createConnection({
    host: 'aztechpro.com',
    user: 'admin',
    password: 'Haiconcacon123',
    database: 'ssrabzle_wp101'
  });

  connection.connect(function(err) {
    if (err) {
      console.error('error connecting: ' + err.stack);
      return;
    }

    console.log('connected as id ' + connection.threadId);
  });


});

module.exports = router;
