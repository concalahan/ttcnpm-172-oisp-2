var express = require('express');
var http = require('http');
var bodyParser = require('body-parser');
var morgan = require('morgan');
var app = express();

var index = require('./routes/index');
var insertDB = require('./routes/insertDB');
var mongoose = require('mongoose');
var cors = require('cors');

// // DB setup
// mongoose.connect('mongodb://localhost/myapp');

// App setup
app.use(morgan('combined'));
app.use(cors()); // can config
app.use(bodyParser.json({type: '*/*'}));

app.use("/", index);
app.use("/", insertDB);

// Server setup
const port = process.env.PORT || 3090;
const server = http.createServer(app);
server.listen(port);

console.log('Server listening on: ', port);
